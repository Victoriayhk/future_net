#ifndef __WRITERESULT_H__
#define __WRITERESULT_H__

void record_result(unsigned char IsExistRoad);
void write_result2file(const char * const filename);

//void write_VVcost2file(const char * const filename);
//void write_Vpath2file(const char * const filename);
//void release_buff(char ** const buff, const int valid_item_num);

#endif
