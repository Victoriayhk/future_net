#ifndef __READINFO_H__
#define __READINFO_H__

int read_file(char ** const buff, const unsigned int spec, const char * const filename);
void V_init(const char * const filename);
void Road_init(const char * const filename);

#endif
